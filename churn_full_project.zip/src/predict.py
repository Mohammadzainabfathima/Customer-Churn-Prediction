"""Load saved model and run predictions on new data.

Example:
    python src/predict.py --model models/best_model.joblib --input data/customer_churn.csv --output predictions.csv
"""
import argparse
import pandas as pd
import joblib
import os

def load_model(model_path):
    obj = joblib.load(model_path)
    return obj.get('model'), obj.get('encoder')

def prepare_input(df):
    # Minimal cleaning to align with training
    if 'TotalCharges' in df.columns:
        df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce').fillna(0.0)
    # Feature engineering similar to training
    df['AvgChargesPerMonth'] = df.apply(lambda r: r['TotalCharges']/r['tenure'] if r['tenure']>0 else r['MonthlyCharges'], axis=1)
    df['HasPhoneService'] = (df['PhoneService'] == 'Yes').astype(int)
    df['HasInternet'] = (df['InternetService'] != 'No').astype(int)
    return df

def predict_and_save(model, encoder, df, output_path):
    X = df.drop(columns=[c for c in ['customerID','Churn'] if c in df.columns], errors='ignore')
    # apply encoder if available (encoder was OneHotEncoder)
    if encoder is not None:
        categorical = X.select_dtypes(include=['object','category']).columns.tolist()
        if len(categorical) > 0:
            X_enc = pd.DataFrame(encoder.transform(X[categorical]), index=X.index, columns=encoder.get_feature_names_out(categorical))
            X = X.drop(columns=categorical).join(X_enc)
    X = X.fillna(0)
    preds = model.predict(X)
    proba = model.predict_proba(X)[:,1] if hasattr(model, 'predict_proba') else None
    out = df[['customerID']].copy() if 'customerID' in df.columns else pd.DataFrame({'row_id': df.index})
    out['prediction'] = preds
    if proba is not None:
        out['probability'] = proba
    out.to_csv(output_path, index=False)
    print(f"Predictions saved to {output_path}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True, help='path to saved model joblib')
    parser.add_argument('--input', required=True, help='input csv path for prediction')
    parser.add_argument('--output', default='predictions.csv', help='output csv path')
    args = parser.parse_args()
    model, encoder = load_model(args.model)
    df = pd.read_csv(args.input)
    df = prepare_input(df)
    predict_and_save(model, encoder, df, args.output)

"""Train and evaluate churn prediction models.

Saves the best model into the output folder as 'best_model.joblib'.
"""
import argparse
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from preprocess import load_data, basic_cleaning, feature_engineering, get_features_and_target, encode_features

def evaluate_model(model, X_test, y_test):
    preds = model.predict(X_test)
    print("Accuracy:", accuracy_score(y_test, preds))
    print("Classification Report:\n", classification_report(y_test, preds))
    cm = confusion_matrix(y_test, preds)
    print("Confusion Matrix:\n", cm)

def main(data_path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    df = load_data(data_path)
    df = basic_cleaning(df)
    df = feature_engineering(df)

    X, y = get_features_and_target(df)
    # simple train/validation split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    X_train_enc, X_test_enc, encoder = encode_features(X_train, X_test)

    # Some classifiers require no NaNs and numeric arrays
    X_train_enc = X_train_enc.fillna(0)
    X_test_enc = X_test_enc.fillna(0)

    # Standard models
    models = {
        'logistic': LogisticRegression(max_iter=1000),
        'random_forest': RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    }

    best_model = None
    best_score = -1
    for name, model in models.items():
        print(f"Training {name}...")
        # cross-validated accuracy
        scores = cross_val_score(model, X_train_enc, y_train, cv=5, scoring='accuracy', n_jobs=-1)
        print(f"CV accuracy for {name}: {np.mean(scores):.4f} (+/- {np.std(scores):.4f})")
        model.fit(X_train_enc, y_train)
        evaluate_model(model, X_test_enc, y_test)
        acc = accuracy_score(y_test, model.predict(X_test_enc))
        if acc > best_score:
            best_score = acc
            best_model = (name, model)

    # Save the best model and encoder
    model_name, model_obj = best_model
    model_path = os.path.join(out_dir, 'best_model.joblib')
    joblib.dump({'model': model_obj, 'encoder': encoder}, model_path)
    print(f"Saved best model ({model_name}) to {model_path}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', required=True, help='path to csv data file')
    parser.add_argument('--out', default='models', help='output directory to save model')
    args = parser.parse_args()
    # Need to ensure import path for preprocess
    import sys
    sys.path.append('src')
    from src import preprocess as preprocess_module  # to ensure relative imports do not break when running from repo root
    # But our functions are defined in src/preprocess.py; import them directly
    from src.preprocess import load_data, basic_cleaning, feature_engineering, get_features_and_target, encode_features
    main(args.data, args.out)

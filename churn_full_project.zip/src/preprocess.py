"""Preprocessing utilities for churn project."""
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer

def load_data(path):
    return pd.read_csv(path)

def basic_cleaning(df):
    # Ensure TotalCharges numeric (in case of dataset differences)
    if 'TotalCharges' in df.columns:
        df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
        # if there are NaNs because tenure=0 then fill with 0
        df['TotalCharges'] = df['TotalCharges'].fillna(0.0)
    return df

def feature_engineering(df):
    # Example feature: avg charges per month (guard divide-by-zero)
    df = df.copy()
    df['AvgChargesPerMonth'] = df.apply(lambda r: r['TotalCharges']/r['tenure'] if r['tenure']>0 else r['MonthlyCharges'], axis=1)
    # Binary encode some columns
    df['HasPhoneService'] = (df['PhoneService'] == 'Yes').astype(int)
    df['HasInternet'] = (df['InternetService'] != 'No').astype(int)
    return df

def get_features_and_target(df, drop_cols=None):
    if drop_cols is None:
        drop_cols = ['customerID','Churn']
    X = df.drop(columns=[c for c in drop_cols if c in df.columns])
    y = df['Churn'].astype(int)
    return X, y

def encode_features(X_train, X_valid=None):
    # Use one-hot encoding for categorical columns
    X_train = X_train.copy()
    categorical = X_train.select_dtypes(include=['object','category']).columns.tolist()
    # Keep track of columns for pipeline-like behavior
    encoder = OneHotEncoder(handle_unknown='ignore', sparse=False)
    if len(categorical) > 0:
        enc = encoder.fit(X_train[categorical])
        X_train_enc = pd.DataFrame(enc.transform(X_train[categorical]), index=X_train.index, columns=enc.get_feature_names_out(categorical))
        X_train = X_train.drop(columns=categorical).join(X_train_enc)
        if X_valid is not None:
            X_valid_enc = pd.DataFrame(enc.transform(X_valid[categorical]), index=X_valid.index, columns=enc.get_feature_names_out(categorical))
            X_valid = X_valid.drop(columns=categorical).join(X_valid_enc)
    else:
        enc = None
    return X_train, X_valid, enc
